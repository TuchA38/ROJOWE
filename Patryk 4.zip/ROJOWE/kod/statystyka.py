"""Testy statystyczne z instrukcji (tabela "Testy statystyczne - porównywanie metod")
oraz z pracy Derrac i in. (2011), "A practical tutorial on the use of nonparametric
statistical tests as a methodology for comparing evolutionary and swarm intelligence algorithms".

Wszystkie testy działają na błędzie ``f - f_opt`` (mniejszy = lepszy).

  Shapiro-Wilk          shapiro_table         normalność 50 wyników
  Levene/Brown-Forsythe variance_table        jednorodność wariancji
  Mann-Whitney U        pairwise_table        dwie metody na jednej funkcji (+ Holm)
  Cliff's delta         pairwise_table        wielkość efektu
  Wilcoxon signed-rank  wilcoxon_over_functions  dwie metody na zbiorze funkcji (parowanie po funkcji)
  Friedman (+Iman-Dav.) friedman_test         wiele metod na zbiorze funkcji
  Kendall's W           friedman_test         wielkość efektu / zgodność rang
  Nemenyi               friedman_test         post-hoc wszystkie pary
  Holm                  friedman_test, holm   post-hoc względem metody kontrolnej / korekta p
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as st

ALPHA = 0.05


# --------------------------------------------------------------------------
# Pomocnicze
# --------------------------------------------------------------------------

def holm(pvalues) -> np.ndarray:
    """Korekta Holma-Bonferroniego dla wielokrotnych porównań (zwraca skorygowane p)."""
    p = np.asarray(pvalues, dtype=float)
    out = np.full_like(p, np.nan)
    mask = ~np.isnan(p)
    pv = p[mask]
    m = len(pv)
    if m == 0:
        return out
    order = np.argsort(pv)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (m - rank) * pv[idx]))
        adj[idx] = running
    out[mask] = adj
    return out


def cliffs_delta(a, b) -> float:
    """Cliff's delta = P(a > b) - P(a < b). Dla błędów: delta < 0 oznacza, że a jest lepsze."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    gt = (a[:, None] > b[None, :]).sum()
    lt = (a[:, None] < b[None, :]).sum()
    return float((gt - lt) / (len(a) * len(b)))


def cliffs_magnitude(delta: float) -> str:
    """Progi Romano i in. (2006)."""
    d = abs(delta)
    if d < 0.147:
        return "pomijalny"
    if d < 0.33:
        return "mały"
    if d < 0.474:
        return "średni"
    return "duży"


def _errors(df, algo, dim, fid):
    sel = df[(df["algorithm"] == algo) & (df["dim"] == dim) & (df["fid"] == fid)]
    return sel.sort_values("seed")["error"].to_numpy(float)


# --------------------------------------------------------------------------
# Pojedyncza metoda
# --------------------------------------------------------------------------

def shapiro_table(df: pd.DataFrame, alpha: float = ALPHA) -> pd.DataFrame:
    """Shapiro-Wilk dla każdego (metoda, wymiar, funkcja): czy 50 wyników ma rozkład normalny?"""
    rows = []
    for (algo, dim, fid), grp in df.groupby(["algorithm", "dim", "fid"]):
        x = grp["error"].to_numpy(float)
        if len(x) < 3 or np.ptp(x) == 0:
            w, p, note = np.nan, np.nan, "wyniki stałe - test nieokreślony"
        else:
            w, p = st.shapiro(x)
            note = "normalny" if p > alpha else "nienormalny"
        rows.append({"Metoda": algo, "Wymiar": dim, "fid": fid, "W": w, "p": p, "Wniosek": note})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Dwie metody
# --------------------------------------------------------------------------

def variance_table(df: pd.DataFrame, algos, alpha: float = ALPHA) -> pd.DataFrame:
    """Levene (center=mean) i Brown-Forsythe (center=median) - jednorodność wariancji między metodami."""
    rows = []
    for dim in sorted(df["dim"].unique()):
        for fid in sorted(df["fid"].unique()):
            groups = [_errors(df, a, dim, fid) for a in algos]
            if any(len(g) < 2 for g in groups) or all(np.ptp(g) == 0 for g in groups):
                rows.append({"Wymiar": dim, "fid": fid, "Levene p": np.nan, "Brown-Forsythe p": np.nan})
                continue
            rows.append({"Wymiar": dim, "fid": fid,
                         "Levene p": st.levene(*groups, center="mean").pvalue,
                         "Brown-Forsythe p": st.levene(*groups, center="median").pvalue})
    out = pd.DataFrame(rows)
    out["Wariancje jednorodne (BF)"] = out["Brown-Forsythe p"] > alpha
    return out


def pairwise_table(df: pd.DataFrame, algo_a: str, algo_b: str, alpha: float = ALPHA) -> pd.DataFrame:
    """Mann-Whitney U (dwustronny) + Cliff's delta dla każdej funkcji i wymiaru.

    p-wartości korygowane metodą Holma w obrębie wymiaru (24 porównania).
    Werdykt: '+' algo_a istotnie lepszy, '-' istotnie gorszy, '=' brak istotnej różnicy.
    """
    rows = []
    for dim in sorted(set(df.loc[df["algorithm"] == algo_a, "dim"]) & set(df.loc[df["algorithm"] == algo_b, "dim"])):
        for fid in sorted(df["fid"].unique()):
            a, b = _errors(df, algo_a, dim, fid), _errors(df, algo_b, dim, fid)
            if len(a) == 0 or len(b) == 0:
                continue
            if np.array_equal(np.unique(a), np.unique(b)) and np.ptp(a) == 0:
                u, p = np.nan, 1.0
            else:
                u, p = st.mannwhitneyu(a, b, alternative="two-sided")
            d = cliffs_delta(a, b)
            rows.append({"Wymiar": dim, "fid": fid, f"Mediana {algo_a}": np.median(a),
                         f"Mediana {algo_b}": np.median(b), "U": u, "p": p, "delta Cliffa": d,
                         "Efekt": cliffs_magnitude(d)})
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["p (Holm)"] = np.nan
    for dim, idx in out.groupby("Wymiar").groups.items():
        out.loc[idx, "p (Holm)"] = holm(out.loc[idx, "p"])
    out["Werdykt"] = np.where(out["p (Holm)"] < alpha, np.where(out["delta Cliffa"] < 0, "+", "-"), "=")
    return out


def wilcoxon_over_functions(df: pd.DataFrame, algo_a: str, algo_b: str, dims=None,
                            stat: str = "mean") -> dict:
    """Wilcoxon signed-rank na zbiorze problemów (Derrac i in., rozdz. 3.2).

    Jeden problem = (funkcja, wymiar); wartość = średni (lub medianowy) błąd z 50 przebiegów.
    Parowanie jest uzasadnione, bo obie metody rozwiązują te same problemy.
    """
    agg = "mean" if stat == "mean" else "median"
    sub = df[df["algorithm"].isin([algo_a, algo_b])]
    if dims:
        sub = sub[sub["dim"].isin(dims)]
    pivot = sub.groupby(["dim", "fid", "algorithm"])["error"].agg(agg).unstack("algorithm").dropna()
    a, b = pivot[algo_a].to_numpy(), pivot[algo_b].to_numpy()
    diff = b - a                       # > 0: algo_a ma mniejszy błąd (lepszy)
    ranks = st.rankdata(np.abs(diff))
    zero = diff == 0
    r_plus = ranks[diff > 0].sum() + 0.5 * ranks[zero].sum()
    r_minus = ranks[diff < 0].sum() + 0.5 * ranks[zero].sum()
    if np.all(zero):
        p = 1.0
    else:
        p = st.wilcoxon(a, b, zero_method="zsplit").pvalue
    return {"A": algo_a, "B": algo_b, "Liczba problemów": len(diff), "R+ (A lepszy)": r_plus,
            "R- (B lepszy)": r_minus, "p": p, "Wygrane A": int((diff > 0).sum()),
            "Remisy": int(zero.sum()), "Wygrane B": int((diff < 0).sum())}


# --------------------------------------------------------------------------
# Wiele metod
# --------------------------------------------------------------------------

def friedman_test(df: pd.DataFrame, algos, dims=None, stat: str = "mean", alpha: float = ALPHA) -> dict:
    """Test Friedmana (+ Iman-Davenport), Kendall's W, post-hoc Nemenyi i Holm.

    Bloki = problemy (funkcja, wymiar), wartości = średni (mediana) błąd z 50 przebiegów.
    Zwraca słownik z tabelami: 'ranks', 'nemenyi', 'holm' i liczbami testu.
    """
    algos = list(algos)
    k = len(algos)
    agg = "mean" if stat == "mean" else "median"
    sub = df[df["algorithm"].isin(algos)]
    if dims:
        sub = sub[sub["dim"].isin(dims)]
    matrix = sub.groupby(["dim", "fid", "algorithm"])["error"].agg(agg).unstack("algorithm")[algos].dropna()
    n = len(matrix)
    ranks = matrix.rank(axis=1, method="average")      # 1 = najlepszy (najmniejszy błąd)
    avg_rank = ranks.mean().sort_values()

    result = {"n_problems": n, "k_algorithms": k, "matrix": matrix, "ranks_per_problem": ranks,
              "ranks": avg_rank.rename("Średnia ranga").reset_index().rename(columns={"algorithm": "Metoda"})}
    if k < 3:
        result["note"] = "Friedman wymaga >= 3 metod - użyj wilcoxon_over_functions."
        return result

    chi2, p = st.friedmanchisquare(*[matrix[a].to_numpy() for a in algos])
    ff = (n - 1) * chi2 / (n * (k - 1) - chi2) if n * (k - 1) != chi2 else np.inf
    p_ff = st.f.sf(ff, k - 1, (k - 1) * (n - 1))
    w = chi2 / (n * (k - 1))
    result.update({"chi2": chi2, "p": p, "iman_davenport_F": ff, "iman_davenport_p": p_ff,
                   "kendall_W": w, "significant": p < alpha})

    # Nemenyi: wszystkie pary; CD = q_alpha * sqrt(k(k+1)/(6n))
    se = np.sqrt(k * (k + 1) / (6.0 * n))
    q_alpha = st.studentized_range.ppf(1 - alpha, k, 1e6) / np.sqrt(2)
    result["nemenyi_CD"] = q_alpha * se
    nem = pd.DataFrame(np.ones((k, k)), index=algos, columns=algos)
    for i, a in enumerate(algos):
        for j, b in enumerate(algos):
            if i < j:
                q = abs(avg_rank[a] - avg_rank[b]) / se * np.sqrt(2)
                nem.loc[a, b] = nem.loc[b, a] = st.studentized_range.sf(q, k, 1e6)
    result["nemenyi"] = nem

    # Holm: metoda kontrolna (najlepsza średnia ranga) vs pozostałe
    control = avg_rank.index[0]
    others = [a for a in avg_rank.index if a != control]
    z = [(avg_rank[o] - avg_rank[control]) / se for o in others]
    p_unadj = [2 * st.norm.sf(abs(zz)) for zz in z]
    result["control"] = control
    result["holm"] = pd.DataFrame({"Metoda": others, "z": z, "p": p_unadj, "p (Holm)": holm(p_unadj)})
    result["holm"]["Istotnie gorsza od kontrolnej"] = result["holm"]["p (Holm)"] < alpha
    return result


def friedman_summary(res: dict) -> pd.DataFrame:
    keys = ["n_problems", "k_algorithms", "chi2", "p", "iman_davenport_F", "iman_davenport_p",
            "kendall_W", "nemenyi_CD", "control", "significant", "note"]
    return pd.DataFrame([{"Miara": k, "Wartość": res[k]} for k in keys if k in res])
