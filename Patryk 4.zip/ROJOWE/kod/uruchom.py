"""Główny plik projektu - wszystko uruchamia się stąd.

    python kod/uruchom.py <polecenie> [opcje]

Polecenia:
    weryfikuj                    zgodność 24 benchmarków z oficjalnym COCO
    funkcje                      wizualizacje 24 funkcji -> raporty/funkcje_benchmarkowe
    info OriginalAOA             parametry algorytmu użyte w protokole
    oblicz OriginalAOA           eksperyment (50 ziaren x 24 funkcje x wymiary), wznawia przerwane
    status                       postęp obliczeń wszystkich algorytmów
    raport OriginalAOA           XLSX + tabele LaTeX + wykresy + testy statystyczne
    demo OriginalAOA             wykresy MEALPY i animacja roju dla jednego przebiegu 2D
    porownanie ALG1 ALG2 ...     rozdział podsumowujący: wszystkie algorytmy razem

Przykłady:
    python kod/uruchom.py oblicz OriginalAOA --wymiary 2 3 10      # wariant na 3.0
    python kod/uruchom.py oblicz OriginalAOA                       # wszystkie wymiary (4.0 / 5.0)
    python kod/uruchom.py oblicz RandomSearch                      # punkt odniesienia do testów
    python kod/uruchom.py raport OriginalAOA --porownaj RandomSearch
    python kod/uruchom.py porownanie OriginalAOA OriginalCGO OriginalCircleSA OriginalGBO OriginalINFO OriginalEP
"""

from __future__ import annotations

import os
import sys

# Python nie tworzy folderów __pycache__ (podręcznych kopii plików .py) - także w procesach roboczych.
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse  # noqa: E402
import json  # noqa: E402
from pathlib import Path  # noqa: E402

import ustawienia  # noqa: E402

# ==========================================================================
# Raporty - komplet materiałów do sprawozdania
# ==========================================================================


def _stats_latex(wilcoxon_rows: list[dict], friedman: dict | None, label_prefix: str) -> str:
    import pandas as pd

    import wyniki

    parts = []
    if wilcoxon_rows:
        w = pd.DataFrame(wilcoxon_rows)
        parts.append(wyniki.latex_table(
            w, caption="Test Wilcoxona (rangowanych znaków) na zbiorze problemów (średni błąd z 50 przebiegów)",
            label=f"tab:{label_prefix}_wilcoxon", text_cols=["A", "B", "Wymiar"],
            number_cols=["Liczba problemów", "R+ (A lepszy)", "R- (B lepszy)", "p"]))
    if friedman and "chi2" in friedman:
        r = friedman["ranks"].copy()
        parts.append(wyniki.latex_table(
            r, caption=(f"Średnie rangi Friedmana ($\\chi^2$={friedman['chi2']:.2f}, p={friedman['p']:.2e}, "
                        f"W Kendalla={friedman['kendall_W']:.3f}, CD Nemenyi={friedman['nemenyi_CD']:.2f})"),
            label=f"tab:{label_prefix}_friedman", text_cols=["Metoda"], number_cols=["Średnia ranga"]))
    return "\n".join(parts)


def make_report(algorithm: str, compare_with=(), results_dir: Path = ustawienia.RESULTS_DIR,
                reports_dir: Path = ustawienia.REPORTS_DIR, dims=None, figures: bool = True) -> Path:
    """Tworzy raporty/<algorytm>/ z kompletem materiałów do sprawozdania.

    compare_with - inne algorytmy (np. ["RandomSearch"] albo algorytmy z poprzednich
    sprawozdań) do testów statystycznych i wspólnych wykresów.
    """
    import matplotlib.pyplot as plt
    import pandas as pd

    import statystyka
    import wykresy
    import wyniki

    compare_with = [a for a in compare_with if a != algorithm]
    out = Path(reports_dir) / algorithm
    acr = wyniki.acronym(algorithm)
    df_all = wyniki.load_runs([algorithm, *compare_with], results_dir, dims=dims)
    df = df_all[df_all["algorithm"] == algorithm]
    dims_avail = sorted(df["dim"].unique())
    print(f"[{algorithm}] przebiegi: {len(df)}; wymiary: {dims_avail}")
    print(wyniki.completeness(df_all).to_string(index=False))

    # --- testy statystyczne -------------------------------------------------
    extra = {"Shapiro-Wilk": statystyka.shapiro_table(df)}
    wilcoxon_rows, friedman = [], None
    for other in compare_with:
        extra[f"MW vs {wyniki.acronym(other)}"] = statystyka.pairwise_table(df_all, algorithm, other)
        for dim in dims_avail:
            row = statystyka.wilcoxon_over_functions(df_all, algorithm, other, dims=[dim])
            row["Wymiar"] = f"{dim}D"
            wilcoxon_rows.append(row)
        row = statystyka.wilcoxon_over_functions(df_all, algorithm, other)
        row["Wymiar"] = "wszystkie"
        wilcoxon_rows.append(row)
    if wilcoxon_rows:
        extra["Wilcoxon"] = pd.DataFrame(wilcoxon_rows)
    algos = [algorithm, *compare_with]
    if len(algos) >= 3:
        friedman = statystyka.friedman_test(df_all, algos)
        extra["Friedman"] = statystyka.friedman_summary(friedman)
        extra["Friedman rangi"] = friedman["ranks"]
        extra["Holm vs kontrolna"] = friedman["holm"]
        extra["Nemenyi p"] = friedman["nemenyi"].reset_index().rename(columns={"index": "Metoda"})
    if len(algos) >= 2:
        extra["Levene-Brown-Forsythe"] = statystyka.variance_table(df_all, algos)

    # --- XLSX ---------------------------------------------------------------
    xlsx = wyniki.export_xlsx(df, out / f"{acr}_wyniki.xlsx", extra_sheets=extra, results_dir=results_dir)
    print(f"  XLSX: {xlsx}")

    # --- LaTeX --------------------------------------------------------------
    tex = wyniki.export_latex_tables(df, out / "latex")
    stats_tex = _stats_latex(wilcoxon_rows, friedman, acr)
    if stats_tex:
        p = out / "latex" / f"{acr}_testy.tex"
        p.write_text(stats_tex, encoding="utf-8")
        tex.append(p)
    print(f"  LaTeX: {len(tex)} plików w {out / 'latex'}")

    # --- wykresy ------------------------------------------------------------
    if figures:
        figdir = out / "wykresy"
        for dim in dims_avail:
            plt.close(wykresy.plot_convergence(df_all, dim, algos, figdir / f"{acr}_zbieznosc_{dim}D.png"))
            plt.close(wykresy.plot_boxplots(df_all, dim, algos, figdir / f"{acr}_boxplot_{dim}D.png"))
        plt.close(wykresy.plot_error_heatmap(df, algorithm, figdir / f"{acr}_heatmapa.png"))
        if friedman and "chi2" in friedman:
            plt.close(wykresy.plot_ranks(friedman, figdir / f"{acr}_rangi_friedman.png"))
        print(f"  Wykresy: {figdir}")
    return out


def make_comparison(algorithms, results_dir: Path = ustawienia.RESULTS_DIR,
                    reports_dir: Path = ustawienia.REPORTS_DIR, name: str = "porownanie", dims=None) -> Path:
    """Rozdział podsumowujący: wszystkie algorytmy razem (ranking, testy, wspólne wykresy)."""
    import matplotlib.pyplot as plt
    import pandas as pd

    import statystyka
    import wykresy
    import wyniki

    algorithms = list(algorithms)
    out = Path(reports_dir) / name
    df = wyniki.load_runs(algorithms, results_dir, dims=dims)
    dims_avail = sorted(df["dim"].unique())
    extra = {}
    for dim in dims_avail:
        fr = statystyka.friedman_test(df, algorithms, dims=[dim])
        extra[f"Friedman {dim}D"] = statystyka.friedman_summary(fr)
        extra[f"Rangi {dim}D"] = fr["ranks"]
    fr_all = statystyka.friedman_test(df, algorithms)
    extra["Friedman wszystkie"] = statystyka.friedman_summary(fr_all)
    extra["Rangi wszystkie"] = fr_all["ranks"]
    if "holm" in fr_all:
        extra["Holm vs kontrolna"] = fr_all["holm"]
        extra["Nemenyi p"] = fr_all["nemenyi"].reset_index().rename(columns={"index": "Metoda"})
    pair_rows = [statystyka.wilcoxon_over_functions(df, a, b)
                 for i, a in enumerate(algorithms) for b in algorithms[i + 1:]]
    pairs = pd.DataFrame(pair_rows)
    if not pairs.empty:
        pairs["p (Holm)"] = statystyka.holm(pairs["p"])
        extra["Wilcoxon pary"] = pairs
    xlsx = wyniki.export_xlsx(df, out / "wszystkie_wyniki.xlsx", extra_sheets=extra, results_dir=results_dir)
    figdir = out / "wykresy"
    for dim in dims_avail:
        plt.close(wykresy.plot_convergence(df, dim, algorithms, figdir / f"zbieznosc_{dim}D.png", band=False))
        plt.close(wykresy.plot_boxplots(df, dim, algorithms, figdir / f"boxplot_{dim}D.png"))
    if "chi2" in fr_all:
        plt.close(wykresy.plot_ranks(fr_all, figdir / "rangi_friedman.png"))
    (out / "latex").mkdir(parents=True, exist_ok=True)
    (out / "latex" / "testy.tex").write_text(_stats_latex([], fr_all, "porownanie"), encoding="utf-8")
    print(f"Porównanie zapisane w {out} (XLSX: {xlsx})")
    return out


# ==========================================================================
# Polecenia
# ==========================================================================


def cmd_weryfikuj(args):
    import pandas as pd

    from benchmarki import verify_against_coco

    df = verify_against_coco()
    pd.set_option("display.width", 200)
    print(df.to_string(index=False))
    bad = df[~df["zgodne"]]
    print(f"\nZgodne: {len(df) - len(bad)}/{len(df)}")
    return 0 if bad.empty else 1


def cmd_funkcje(args):
    from wykresy import plot_all_functions

    out = plot_all_functions(args.folder)
    print(f"Wizualizacje 24 funkcji zapisane w {out}")


def cmd_info(args):
    from eksperyment import algorithm_info

    info = algorithm_info(args.algorytm)
    print(json.dumps({k: v for k, v in info.items() if k != "doc"}, indent=2, ensure_ascii=False))
    print("\n" + info["doc"])
    print("\nBudżety FE:", {f"{d}D": ustawienia.max_fe(d) for d in ustawienia.DIMENSIONS})


def cmd_oblicz(args):
    from eksperyment import run_experiment

    if args.wlasny:
        import importlib
        importlib.import_module(args.wlasny)       # moduł z register_algorithm(...)
    seeds = ustawienia.SEEDS[: args.ile_ziaren] if args.ile_ziaren else None
    params = json.loads(args.parametry) if args.parametry else None
    run_experiment(args.algorytm, dims=args.wymiary, fids=args.funkcje, seeds=seeds, workers=args.procesy,
                   results_dir=args.folder_wynikow, params=params, force=args.wymus)


def cmd_status(args):
    from eksperyment import load_done_keys

    root = Path(args.folder_wynikow)
    if not root.exists():
        print("Brak wyników.")
        return
    total = len(ustawienia.FUNCTION_IDS) * len(ustawienia.SEEDS)
    for d in sorted(p for p in root.iterdir() if (p / "runs.jsonl").exists()):
        done = load_done_keys(d / "runs.jsonl")
        per_dim = {dim: sum(1 for k in done if k[1] == dim) for dim in ustawienia.DIMENSIONS}
        cells = "  ".join(f"{dim}D:{n:4d}/{total}" for dim, n in per_dim.items())
        print(f"{d.name:20s} {cells}")


def cmd_raport(args):
    make_report(args.algorytm, compare_with=args.porownaj or [], results_dir=args.folder_wynikow,
                reports_dir=args.folder_raportow, dims=args.wymiary, figures=not args.bez_wykresow)


def cmd_porownanie(args):
    make_comparison(args.algorytmy, results_dir=args.folder_wynikow, reports_dir=args.folder_raportow,
                    name=args.nazwa, dims=args.wymiary)


def cmd_demo(args):
    from wykresy import demo_run

    res, _, outdir, gif = demo_run(args.algorytm, args.funkcja, seed=args.ziarno, outdir=args.folder)
    print(f"Błąd końcowy: {res['error']:.3e}, FE: {res['fe_used']}; wykresy: {outdir}"
          + (f", animacja: {gif}" if gif else ""))


def _foldery(p):
    p.add_argument("--folder-wynikow", default=str(ustawienia.RESULTS_DIR), help="folder z surowymi wynikami")
    p.add_argument("--folder-raportow", default=str(ustawienia.REPORTS_DIR), help="folder z materiałami do sprawozdań")


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(prog="python kod/uruchom.py", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="polecenie", required=True)

    p = sub.add_parser("weryfikuj", help="porównaj benchmarki (ioh) z oficjalnym COCO (cocoex)")
    p.set_defaults(handler=cmd_weryfikuj)

    p = sub.add_parser("funkcje", help="wizualizacje 24 funkcji benchmarkowych")
    p.add_argument("--folder", default=str(ustawienia.FUNCTIONS_FIG_DIR))
    p.set_defaults(handler=cmd_funkcje)

    p = sub.add_parser("info", help="parametry algorytmu użyte w protokole")
    p.add_argument("algorytm")
    p.set_defaults(handler=cmd_info)

    p = sub.add_parser("oblicz", help="uruchom eksperyment (wznawia przerwane obliczenia)")
    p.add_argument("algorytm")
    p.add_argument("--wymiary", type=int, nargs="+", help=f"wymiary (domyślnie {ustawienia.DIMENSIONS})")
    p.add_argument("--funkcje", type=int, nargs="+", help="numery funkcji 1..24 (domyślnie wszystkie)")
    p.add_argument("--ile-ziaren", type=int, help="tylko pierwsze N ziaren (do testów; protokół = 50)")
    p.add_argument("--procesy", type=int, help="liczba procesów (domyślnie liczba rdzeni - 2)")
    p.add_argument("--parametry", help="nadpisanie parametrów jako JSON (protokół: domyślne MEALPY)")
    p.add_argument("--wlasny", help="moduł Pythona rejestrujący własny algorytm")
    p.add_argument("--wymus", action="store_true", help="pozwól dopisać wyniki mimo zmiany parametrów")
    _foldery(p)
    p.set_defaults(handler=cmd_oblicz)

    p = sub.add_parser("status", help="postęp obliczeń dla wszystkich algorytmów")
    _foldery(p)
    p.set_defaults(handler=cmd_status)

    p = sub.add_parser("raport", help="XLSX + LaTeX + wykresy + testy dla jednego algorytmu")
    p.add_argument("algorytm")
    p.add_argument("--porownaj", nargs="+", help="algorytmy do porównania (np. RandomSearch)")
    p.add_argument("--wymiary", type=int, nargs="+")
    p.add_argument("--bez-wykresow", action="store_true")
    _foldery(p)
    p.set_defaults(handler=cmd_raport)

    p = sub.add_parser("porownanie", help="rozdział podsumowujący: wszystkie algorytmy razem")
    p.add_argument("algorytmy", nargs="+")
    p.add_argument("--nazwa", default="porownanie")
    p.add_argument("--wymiary", type=int, nargs="+")
    _foldery(p)
    p.set_defaults(handler=cmd_porownanie)

    p = sub.add_parser("demo", help="wykresy MEALPY i animacja roju dla jednego przebiegu 2D")
    p.add_argument("algorytm")
    p.add_argument("--funkcja", type=int, default=15)
    p.add_argument("--ziarno", type=int, default=ustawienia.SEEDS[0])
    p.add_argument("--folder")
    p.set_defaults(handler=cmd_demo)

    args = parser.parse_args(argv)
    return args.handler(args) or 0


if __name__ == "__main__":
    sys.exit(main())
