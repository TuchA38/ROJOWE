"""Wczytywanie wyników, tabele podsumowań i eksport (XLSX, LaTeX)."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import ustawienia
from benchmarki import FUNCTION_NAMES, sheet_name

CHECKPOINT_IDX = [ustawienia.TRACE_CHECKPOINTS.index(p) for p in ustawienia.REPORT_CHECKPOINTS]
CHECKPOINT_LABELS = [f"{round(p * 100)}% FE" for p in ustawienia.REPORT_CHECKPOINTS]


def acronym(algorithm: str) -> str:
    """'OriginalAOA' -> 'AOA' (do nazw plików wg instrukcji: [akronim]_wyniki.xlsx)."""
    return algorithm[len("Original"):] if algorithm.startswith("Original") else algorithm


# --------------------------------------------------------------------------
# Wczytywanie
# --------------------------------------------------------------------------

def load_runs(algorithms, results_dir: Path = ustawienia.RESULTS_DIR, dims=None) -> pd.DataFrame:
    """Wczytuje przebiegi jednego lub wielu algorytmów do DataFrame (jeden wiersz = jeden przebieg)."""
    if isinstance(algorithms, str):
        algorithms = [algorithms]
    rows = []
    for algo in algorithms:
        path = Path(results_dir) / algo / "runs.jsonl"
        if not path.exists():
            raise FileNotFoundError(f"Brak wyników dla {algo}: {path}. Uruchom: python kod/uruchom.py oblicz {algo}")
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    # Na wypadek zdublowanych przebiegów (np. ręczne łączenie plików) zostawiamy ostatni.
    df = df.drop_duplicates(subset=["algorithm", "fid", "dim", "seed"], keep="last")
    if dims:
        df = df[df["dim"].isin(dims)]
    df["trace_f"] = df["trace_f"].apply(np.asarray)
    df["trace_error"] = [t - fo for t, fo in zip(df["trace_f"], df["f_opt"])]
    df = df.sort_values(["algorithm", "dim", "fid", "seed"]).reset_index(drop=True)
    return df


def load_protocol(algorithm: str, results_dir: Path = ustawienia.RESULTS_DIR) -> dict:
    path = Path(results_dir) / algorithm / "protocol.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def completeness(df: pd.DataFrame) -> pd.DataFrame:
    """Liczba przebiegów na (algorytm, wymiar) - kontrola czy jest komplet 24 x 50."""
    expected = len(ustawienia.FUNCTION_IDS) * len(ustawienia.SEEDS)
    out = df.groupby(["algorithm", "dim"]).size().rename("przebiegi").reset_index()
    out["oczekiwane"] = expected
    out["komplet"] = out["przebiegi"] == expected
    return out


# --------------------------------------------------------------------------
# Tabele
# --------------------------------------------------------------------------

def summary_table(df: pd.DataFrame) -> pd.DataFrame:
    """Statystyki opisowe na (algorytm, wymiar, funkcja)."""
    g = df.groupby(["algorithm", "dim", "fid"])
    out = pd.DataFrame({
        "Funkcja": g["function"].first(),
        "Wartość optimum": g["f_opt"].first(),
        "Liczba przebiegów": g.size(),
        "Średnia": g["best_f"].mean(),
        "Odch. std": g["best_f"].std(ddof=1),
        "Średni błąd": g["error"].mean(),
        "Odch. std błędu": g["error"].std(ddof=1),
        "Mediana błędu": g["error"].median(),
        "Najlepszy błąd": g["error"].min(),
        "Najgorszy błąd": g["error"].max(),
        "Średni czas [s]": g["time_s"].mean(),
        "Odch. std czasu [s]": g["time_s"].std(ddof=1),
        "Średnie FE": g["fe_used"].mean(),
        "Max FE": g["max_fe"].first(),
        f"Sukces (błąd ≤ {ustawienia.TARGET_PRECISION:g}) [%]":
            g["error"].apply(lambda e: 100.0 * np.mean(e <= ustawienia.TARGET_PRECISION)),
    })
    return out.reset_index().rename(columns={"algorithm": "Metoda", "dim": "Wymiar", "fid": "fid"})


def results_wide(df: pd.DataFrame) -> pd.DataFrame:
    """Tabela w formacie z instrukcji:
    Metoda | Funkcja | Wartość optimum | Wyniki (50 powtórzeń) | Średnia | Odch. std | Średni czas | Odch. std czasu
    """
    rows = []
    for (algo, dim, fid), grp in df.groupby(["algorithm", "dim", "fid"]):
        grp = grp.sort_values("seed")
        row = {"Metoda": algo, "Wymiar": dim, "Funkcja": f"f{fid} {FUNCTION_NAMES[fid]}",
               "Wartość optimum": grp["f_opt"].iloc[0]}
        for i, v in enumerate(grp["best_f"], start=1):
            row[f"Wynik {i}"] = v
        row["Średnia wyniku"] = grp["best_f"].mean()
        row["Odch. std wyniku"] = grp["best_f"].std(ddof=1)
        row["Średni błąd (f - f_opt)"] = grp["error"].mean()
        row["Średnia czasu [s]"] = grp["time_s"].mean()
        row["Odch. std czasu [s]"] = grp["time_s"].std(ddof=1)
        row["Średnie FE"] = grp["fe_used"].mean()
        rows.append(row)
    return pd.DataFrame(rows)


def convergence_table(df: pd.DataFrame, value: str = "error", stat: str = "mean") -> pd.DataFrame:
    """Najlepszy dotychczasowy fitness (lub błąd) w punktach 1, 5, 10, 25, 50, 75, 100% FE.

    value: "error" (f - f_opt) albo "f" (surowy fitness); stat: "mean" albo "median".
    """
    col = "trace_error" if value == "error" else "trace_f"
    agg = np.mean if stat == "mean" else np.median
    rows = []
    for (algo, dim, fid), grp in df.groupby(["algorithm", "dim", "fid"]):
        traces = np.vstack(grp[col].to_list())
        row = {"Metoda": algo, "Wymiar": dim, "fid": fid, "Funkcja": FUNCTION_NAMES[fid]}
        for idx, label in zip(CHECKPOINT_IDX, CHECKPOINT_LABELS):
            row[label] = agg(traces[:, idx])
        rows.append(row)
    return pd.DataFrame(rows)


def run_level_table(df: pd.DataFrame) -> pd.DataFrame:
    """Wszystkie przebiegi z punktami kontrolnymi zbieżności (do arkuszy funkcji w XLSX)."""
    out = pd.DataFrame({
        "Metoda": df["algorithm"],
        "Funkcja": "f" + df["fid"].astype(str),
        "Wymiar": df["dim"],
        "Seed": df["seed"],
        "Najlepszy fitness": df["best_f"],
        "Wartość optimum": df["f_opt"],
        "Błąd (f - f_opt)": df["error"],
        "FE użyte": df["fe_used"],
        "Budżet FE": df["max_fe"],
        "Czas [s]": df["time_s"],
        "Epoki": df["epochs"],
        "Pop. size": df["pop_size"],
        f"FE do błędu ≤ {ustawienia.TARGET_PRECISION:g}": df["fe_to_target"],
        "Powód zakończenia": df["stop_reason"],
    })
    traces = np.vstack(df["trace_f"].to_list()) if len(df) else np.empty((0, len(ustawienia.TRACE_CHECKPOINTS)))
    for idx, label in zip(CHECKPOINT_IDX, CHECKPOINT_LABELS):
        out[f"Fitness @ {label}"] = traces[:, idx]
    return out


# --------------------------------------------------------------------------
# Eksport XLSX
# --------------------------------------------------------------------------

def _protocol_rows(protocols: dict) -> pd.DataFrame:
    rows = []
    for algo, proto in protocols.items():
        for key, value in proto.items():
            if key == "runs":
                continue
            if isinstance(value, dict):
                for k2, v2 in value.items():
                    rows.append({"Metoda": algo, "Pole": f"{key}.{k2}", "Wartość": str(v2)})
            else:
                rows.append({"Metoda": algo, "Pole": key, "Wartość": str(value)})
    return pd.DataFrame(rows)


def _autofit(ws, max_width: int = 40):
    from openpyxl.utils import get_column_letter

    for i, column in enumerate(ws.iter_cols(min_row=1, max_row=min(ws.max_row, 60)), start=1):
        width = max((len(str(c.value)) for c in column if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(i)].width = min(max(width + 2, 9), max_width)
    ws.freeze_panes = "B2"


def export_xlsx(df: pd.DataFrame, path: Path, extra_sheets: dict | None = None,
                results_dir: Path = ustawienia.RESULTS_DIR) -> Path:
    """Plik wyników wg instrukcji: osobne arkusze dla funkcji benchmarkowych (50 wyników
    dla każdej metody i wymiaru + progi zbieżności), arkusze podsumowania i protokołu."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    protocols = {a: load_protocol(a, results_dir) for a in df["algorithm"].unique()}
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        _protocol_rows(protocols).to_excel(xw, sheet_name="Protokół", index=False)
        completeness(df).to_excel(xw, sheet_name="Kompletność", index=False)
        summary_table(df).to_excel(xw, sheet_name="Podsumowanie", index=False)
        results_wide(df).to_excel(xw, sheet_name="Wyniki 50 powtórzeń", index=False)
        convergence_table(df, "f").to_excel(xw, sheet_name="Zbieżność (fitness)", index=False)
        convergence_table(df, "error").to_excel(xw, sheet_name="Zbieżność (błąd)", index=False)
        for name, table in (extra_sheets or {}).items():
            table.to_excel(xw, sheet_name=name[:31], index=False)
        runs = run_level_table(df)
        for fid in sorted(df["fid"].unique()):
            runs[df["fid"].values == fid].to_excel(xw, sheet_name=sheet_name(fid), index=False)
        for ws in xw.book.worksheets:
            _autofit(ws)
    return path


# --------------------------------------------------------------------------
# Eksport LaTeX (wklejany do szablonu Overleaf; wymaga \usepackage{booktabs})
# --------------------------------------------------------------------------

def latex_number(x, digits: int = 2) -> str:
    """1.234e-05 -> $1.23\\cdot10^{-5}$ ; wartości 'zwykłe' bez notacji wykładniczej."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "--"
    x = float(x)
    if x == 0:
        return "$0$"
    if 1e-2 <= abs(x) < 1e4:
        return f"${x:.{digits + 1}g}$" if abs(x) < 1 else f"${x:.{digits}f}$"
    mant, exp = f"{x:.{digits}e}".split("e")
    return f"${mant}\\cdot10^{{{int(exp)}}}$"


def _latex_escape(text: str) -> str:
    return str(text).replace("&", "\\&").replace("%", "\\%").replace("_", "\\_").replace("#", "\\#")


def latex_table(table: pd.DataFrame, caption: str, label: str, number_cols=(), text_cols=(),
                col_format: str | None = None, size: str = "\\footnotesize") -> str:
    cols = list(text_cols) + list(number_cols)
    col_format = col_format or ("l" * len(text_cols) + "r" * len(number_cols))
    lines = [
        "\\begin{table}[htbp]",
        "\\centering",
        size,
        f"\\caption{{{caption}}}",
        f"\\label{{{label}}}",
        "\\resizebox{\\textwidth}{!}{%",
        f"\\begin{{tabular}}{{{col_format}}}",
        "\\toprule",
        " & ".join(_latex_escape(c) for c in cols) + " \\\\",
        "\\midrule",
    ]
    for _, row in table.iterrows():
        cells = [_latex_escape(row[c]) for c in text_cols] + [latex_number(row[c]) for c in number_cols]
        lines.append(" & ".join(cells) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}}", "\\end{table}", ""]
    return "\n".join(lines)


def export_latex_tables(df: pd.DataFrame, outdir: Path) -> list[Path]:
    """Dla każdego algorytmu i wymiaru: tabela wyników i tabela zbieżności (.tex)."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    written = []
    summ = summary_table(df)
    conv = convergence_table(df, "error")
    for algo in df["algorithm"].unique():
        acr = acronym(algo)
        for dim in sorted(df.loc[df["algorithm"] == algo, "dim"].unique()):
            s = summ[(summ["Metoda"] == algo) & (summ["Wymiar"] == dim)].copy()
            s["Funkcja"] = "f" + s["fid"].astype(str) + " " + s["Funkcja"]
            tex = latex_table(
                s, caption=f"Wyniki algorytmu {acr} dla D={dim} (50 uruchomień, błąd $f-f_{{opt}}$)",
                label=f"tab:{acr}_wyniki_{dim}D", text_cols=["Funkcja"],
                number_cols=["Wartość optimum", "Średni błąd", "Odch. std błędu", "Mediana błędu",
                             "Najlepszy błąd", "Najgorszy błąd", "Średni czas [s]", "Odch. std czasu [s]"])
            p = outdir / f"{acr}_wyniki_{dim}D.tex"
            p.write_text(tex, encoding="utf-8")
            written.append(p)

            c = conv[(conv["Metoda"] == algo) & (conv["Wymiar"] == dim)].copy()
            c["Funkcja"] = "f" + c["fid"].astype(str) + " " + c["Funkcja"]
            tex = latex_table(
                c, caption=f"Przebieg zbieżności {acr} dla D={dim} - średni najlepszy dotychczasowy błąd "
                           f"$f-f_{{opt}}$ po wykorzystaniu danej części budżetu FE",
                label=f"tab:{acr}_zbieznosc_{dim}D", text_cols=["Funkcja"], number_cols=CHECKPOINT_LABELS)
            p = outdir / f"{acr}_zbieznosc_{dim}D.tex"
            p.write_text(tex, encoding="utf-8")
            written.append(p)
    return written
