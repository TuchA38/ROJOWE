"""Eksperyment: algorytmy, licznik budżetu FE i uruchamianie przebiegów.

Algorytmy
---------
Algorytm identyfikujemy nazwą klasy z MEALPY (np. "OriginalAOA"), więc każdy
algorytm z tematu działa bez zmian w kodzie. Dodatkowo:
  * ``RandomSearch`` - losowe przeszukiwanie, punkt odniesienia do testów statystycznych,
  * własna implementacja - klasa dziedzicząca po ``mealpy.Optimizer`` zarejestrowana przez
    ``register_algorithm("MojAOA", MojAOA)`` w osobnym pliku .py
    (uruchomienie: ``python kod/uruchom.py oblicz MojAOA --wlasny nazwa_modulu``).

Pojedyncze uruchomienie (``run_single``) - trzy zasady z instrukcji:
  1. nowy obiekt algorytmu i nowa funkcja celu,
  2. własne ziarno,
  3. pozostałe parametry identyczne (domyślne MEALPY, epoch = limit techniczny).
Licznik FE owija funkcję celu: liczy KAŻDE wywołanie (także inicjalizację populacji),
zatrzymuje algorytm dokładnie po ``max_fe`` wywołaniach i zapisuje najlepszy
dotychczasowy fitness co 1% budżetu (krzywa zbieżności).

Cały eksperyment (``run_experiment``) liczy równolegle na wielu rdzeniach i dopisuje
każdy przebieg od razu do ``wyniki_przebiegow/<algorytm>/runs.jsonl`` - przerwane
obliczenia można wznowić, wykonane przebiegi są pomijane.
"""

from __future__ import annotations

import importlib
import json
import math
import os
import platform
import random
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import numpy as np
from mealpy import FloatVar, Optimizer, Problem

import ustawienia
from benchmarki import Benchmark

# ==========================================================================
# Algorytmy
# ==========================================================================

# Nazwa -> "moduł:Klasa" (ładowane leniwie, także w procesach roboczych)
_CUSTOM: dict[str, str] = {}


class RandomSearch(Optimizer):
    """Losowe przeszukiwanie - punkt odniesienia (baseline) do testów statystycznych.

    W każdej epoce losuje ``pop_size`` nowych punktów z rozkładu jednostajnego
    i zapamiętuje najlepszy. Każdy sensowny algorytm rojowy powinien go pokonać.
    """

    def __init__(self, epoch: int = 10000, pop_size: int = 100, **kwargs):
        super().__init__(**kwargs)
        self.epoch = self.validator.check_int("epoch", epoch, [1, 100000])
        self.pop_size = self.validator.check_int("pop_size", pop_size, [5, 10000])
        self.set_parameters(["epoch", "pop_size"])
        self.sort_flag = False

    def evolve(self, epoch):
        pop_new = [self.generate_agent() for _ in range(self.pop_size)]
        self.pop = pop_new


def register_algorithm(name: str, cls: type) -> None:
    """Rejestruje własną klasę algorytmu (dziedziczącą po mealpy.Optimizer)."""
    if not issubclass(cls, Optimizer):
        raise TypeError("Klasa algorytmu musi dziedziczyć po mealpy.Optimizer")
    _CUSTOM[name] = f"{cls.__module__}:{cls.__qualname__}"
    get_algorithm_class.cache_clear()


@lru_cache(maxsize=None)
def _mealpy_classes() -> dict[str, type]:
    from mealpy import get_all_optimizers
    return get_all_optimizers(verbose=False)


@lru_cache(maxsize=None)
def get_algorithm_class(name: str) -> type:
    if name == "RandomSearch":
        return RandomSearch
    if name in _CUSTOM:
        module, qualname = _CUSTOM[name].split(":")
        obj = importlib.import_module(module)
        for part in qualname.split("."):
            obj = getattr(obj, part)
        return obj
    classes = _mealpy_classes()
    if name not in classes:
        raise KeyError(f"Nie znaleziono algorytmu '{name}' w MEALPY ani w zarejestrowanych algorytmach.")
    return classes[name]


def build_optimizer(name: str, params: dict | None = None) -> Optimizer:
    """Tworzy NOWY obiekt algorytmu (zasada 1 protokołu: nowy obiekt dla każdego uruchomienia).

    ``epoch`` ustawiamy na techniczny limit z protokołu; pozostałe parametry
    zostają domyślne (MEALPY), chyba że jawnie podano ``params``.
    """
    cls = get_algorithm_class(name)
    kwargs = {"epoch": ustawienia.EPOCH}
    kwargs.update(params or {})
    return cls(**kwargs)


def default_parameters(name: str) -> dict:
    """Parametry, z jakimi algorytm zostanie uruchomiony w protokole (domyślne MEALPY + epoch)."""
    opt = build_optimizer(name)
    params = {}
    for key, value in opt.get_parameters().items():
        params[key] = value.item() if isinstance(value, np.generic) else value
    return params


def algorithm_info(name: str) -> dict:
    cls = get_algorithm_class(name)
    doc = (cls.__doc__ or "").strip()
    return {
        "name": name,
        "class": f"{cls.__module__}.{cls.__qualname__}",
        "parameters": default_parameters(name),
        "doc": doc,
    }


# ==========================================================================
# Licznik budżetu FE i pojedyncze uruchomienie
# ==========================================================================

class BudgetExhausted(Exception):
    """Sygnał zatrzymania algorytmu po wyczerpaniu budżetu FE."""


class BudgetedObjective:
    """Funkcja celu z licznikiem FE, twardym limitem budżetu i zapisem zbieżności."""

    def __init__(self, bench: Benchmark, max_fe: int, checkpoints=ustawienia.TRACE_CHECKPOINTS):
        self.bench = bench
        self.max_fe = max_fe
        self.checkpoint_fe = [max(1, math.ceil(p * max_fe)) for p in checkpoints]
        self.target_f = bench.f_opt + ustawienia.TARGET_PRECISION
        self.armed = False          # przed startem algorytmu wywołania nie są liczone
        self.reset()

    def reset(self):
        self.fe = 0
        self.best_f = math.inf
        self.best_x = None
        self.trace: list[float] = []
        self._next = 0
        self.fe_to_target = None

    def __call__(self, x):
        if not self.armed:
            # Wywołanie kontrolne MEALPY (sprawdzenie liczby celów) - poza budżetem.
            return self.bench(x)
        if self.fe >= self.max_fe:
            raise BudgetExhausted
        y = self.bench(x)
        self.fe += 1
        if y < self.best_f:
            self.best_f = y
            self.best_x = np.array(x, dtype=float, copy=True)
            if self.fe_to_target is None and y <= self.target_f:
                self.fe_to_target = self.fe
        cps = self.checkpoint_fe
        while self._next < len(cps) and self.fe >= cps[self._next]:
            self.trace.append(self.best_f)
            self._next += 1
        return y

    def finalize_trace(self):
        """Gdy algorytm skończył przed budżetem - brakujące punkty = ostatni najlepszy wynik."""
        while len(self.trace) < len(self.checkpoint_fe):
            self.trace.append(self.best_f)


def make_problem(objective: BudgetedObjective, save_population: bool = False) -> Problem:
    bench = objective.bench
    problem = Problem(
        bounds=FloatVar(lb=bench.lb.tolist(), ub=bench.ub.tolist(), name="x"),
        minmax="min",
        obj_func=objective,
        name=f"BBOB-f{bench.fid}-{bench.dim}D",
        log_to=None,
        save_population=save_population,
    )
    _ = problem.n_objs        # wymuszamy wywołanie kontrolne zanim licznik zacznie działać
    objective.armed = True
    return problem


def run_single(algorithm: str, fid: int, dim: int, seed: int, params: dict | None = None,
               save_population: bool = False, return_optimizer: bool = False):
    """Jedno uruchomienie algorytmu na jednej funkcji. Zwraca słownik z wynikami.

    Przy ``return_optimizer=True`` zwraca krotkę ``(wynik, optymalizator)`` -
    przydatne do wykresów MEALPY (historia, trajektorie, populacje).
    """
    random.seed(seed)
    np.random.seed(seed)
    bench = Benchmark(fid, dim)
    budget = ustawienia.max_fe(dim)
    objective = BudgetedObjective(bench, budget)
    problem = make_problem(objective, save_population=save_population)
    optimizer = build_optimizer(algorithm, params)

    t0 = time.perf_counter()
    try:
        optimizer.solve(problem, termination={"max_fe": budget}, seed=seed)
        finished_normally = True
    except BudgetExhausted:
        finished_normally = False
    elapsed = time.perf_counter() - t0

    epochs = len(optimizer.history.list_epoch_time) if optimizer.history else 0
    if objective.fe >= budget:
        stop_reason = "budżet FE wyczerpany"
    elif finished_normally and epochs >= optimizer.epoch:
        stop_reason = f"osiągnięto limit epok ({optimizer.epoch}) przed wyczerpaniem budżetu"
    else:
        stop_reason = (f"algorytm zakończył przed wyczerpaniem budżetu "
                       f"(epoki: {epochs}, licznik FE MEALPY: {optimizer.nfe_counter})")
    objective.finalize_trace()

    result = {
        "algorithm": algorithm,
        "fid": fid,
        "function": bench.name,
        "dim": dim,
        "instance": bench.instance,
        "seed": seed,
        "pop_size": int(getattr(optimizer, "pop_size", 0) or 0),
        "max_fe": budget,
        "fe_used": objective.fe,
        "best_f": objective.best_f,
        "f_opt": bench.f_opt,
        "error": objective.best_f - bench.f_opt,
        "time_s": elapsed,
        "epochs": epochs,
        "stop_reason": stop_reason,
        "fe_to_target": objective.fe_to_target,
        "trace_f": objective.trace,
    }
    if return_optimizer:
        if not finished_normally:
            try:
                optimizer.track_optimize_process()   # domknięcie historii MEALPY po przerwaniu
            except Exception:
                pass
        result["best_x"] = None if objective.best_x is None else objective.best_x.tolist()
        return result, optimizer
    return result


# --------------------------------------------------------------------------
# Eksperyment: wiele przebiegów, równolegle, z możliwością wznowienia
# --------------------------------------------------------------------------

def results_path(algorithm: str, results_dir: Path = ustawienia.RESULTS_DIR) -> Path:
    return Path(results_dir) / algorithm / "runs.jsonl"


def load_done_keys(path: Path) -> set:
    done = set()
    if path.exists():
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue       # np. ucięta ostatnia linia po przerwaniu
                done.add((r["fid"], r["dim"], r["seed"]))
    return done


def _versions() -> dict:
    from importlib.metadata import version, PackageNotFoundError

    out = {"python": sys.version.split()[0], "platform": platform.platform(),
           "processor": platform.processor(), "cpu_count": os.cpu_count()}
    for pkg in ("mealpy", "ioh", "coco-experiment", "numpy", "scipy", "pandas"):
        try:
            out[pkg] = version(pkg)
        except PackageNotFoundError:
            out[pkg] = None
    return out


def write_protocol(algorithm: str, params: dict | None, results_dir: Path, workers: int, force: bool = False) -> dict:
    """Zapisuje konfigurację eksperymentu (wymóg 5: konfiguracja + wersja MEALPY w protokole)."""
    path = Path(results_dir) / algorithm / "protocol.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    info = algorithm_info(algorithm)
    effective = dict(info["parameters"])
    effective.update(params or {})
    protocol = {
        "algorithm": algorithm,
        "class": info["class"],
        "parameters": effective,
        "parameters_overridden": params or {},
        "epoch": ustawienia.EPOCH,
        "max_fe": {f"{d}D": ustawienia.max_fe(d) for d in ustawienia.DIMENSIONS},
        "seeds": [ustawienia.SEEDS[0], ustawienia.SEEDS[-1]],
        "n_seeds": len(ustawienia.SEEDS),
        "benchmark_suite": "BBOB (COCO), implementacja ioh, zweryfikowana z cocoex",
        "instance": ustawienia.INSTANCE,
        "bounds": [ustawienia.LOWER_BOUND, ustawienia.UPPER_BOUND],
        "convergence_checkpoints": ustawienia.REPORT_CHECKPOINTS,
        "target_precision": ustawienia.TARGET_PRECISION,
        "budget_handling": "licznik owija funkcję celu; zatrzymanie dokładnie po max_fe wywołaniach "
                           "(wliczając inicjalizację populacji)",
        "versions": _versions(),
    }
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        if old.get("parameters") != protocol["parameters"] and not force:
            raise RuntimeError(
                f"Parametry algorytmu różnią się od zapisanych w {path}.\n"
                f"  zapisane: {old.get('parameters')}\n  obecne:   {protocol['parameters']}\n"
                "Wyniki nie byłyby porównywalne. Użyj innego katalogu wyników albo --force.")
        protocol["started"] = old.get("started")
        protocol["runs"] = old.get("runs", [])
    else:
        protocol["started"] = datetime.now().isoformat(timespec="seconds")
        protocol["runs"] = []
    protocol["runs"].append({"date": datetime.now().isoformat(timespec="seconds"), "workers": workers})
    path.write_text(json.dumps(protocol, indent=2, ensure_ascii=False), encoding="utf-8")
    return protocol


def _init_worker(custom_specs: dict):
    # Proces roboczy startuje z pustym rejestrem - przekazujemy mu własne algorytmy.
    _CUSTOM.update(custom_specs)


def _task(args):
    algorithm, fid, dim, seed, params = args
    try:
        return run_single(algorithm, fid, dim, seed, params)
    except Exception:
        return {"algorithm": algorithm, "fid": fid, "dim": dim, "seed": seed,
                "error_traceback": traceback.format_exc()}


def _keep_awake(on: bool) -> None:
    """Windows: komputer nie usypia się w trakcie obliczeń (ekran może się wyłączyć)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        es_continuous, es_system_required = 0x80000000, 0x00000001
        flags = es_continuous | (es_system_required if on else 0)
        ctypes.windll.kernel32.SetThreadExecutionState(flags)
    except Exception:
        pass


def _fmt_time(seconds: float) -> str:
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}h{m:02d}m" if h else f"{m}m{s:02d}s"


def run_experiment(algorithm: str, dims=None, fids=None, seeds=None, workers: int | None = None,
                   results_dir: Path = ustawienia.RESULTS_DIR, params: dict | None = None,
                   force: bool = False, verbose: bool = True) -> Path:
    """Wykonuje wszystkie brakujące przebiegi (funkcja x wymiar x ziarno) dla algorytmu."""
    dims = dims or ustawienia.DIMENSIONS
    fids = fids or ustawienia.FUNCTION_IDS
    seeds = seeds or ustawienia.SEEDS
    if workers is None:
        workers = max(1, (os.cpu_count() or 2) - 2)

    out = results_path(algorithm, results_dir)
    out.parent.mkdir(parents=True, exist_ok=True)
    write_protocol(algorithm, params, results_dir, workers, force=force)

    done = load_done_keys(out)
    # Najdroższe zadania (duże D) najpierw - lepsze równoważenie obciążenia rdzeni.
    tasks = [(algorithm, f, d, s, params) for d in sorted(dims, reverse=True) for f in fids for s in seeds
             if (f, d, s) not in done]
    total_fe = sum(ustawienia.max_fe(t[2]) for t in tasks)
    if verbose:
        print(f"[{algorithm}] do wykonania: {len(tasks)} przebiegów "
              f"(pominięto wykonane: {len(done & {(f, d, s) for d in dims for f in fids for s in seeds})}), "
              f"procesy: {workers}, wyniki: {out}", flush=True)
    if not tasks:
        return out

    errors_path = out.with_name("errors.jsonl")
    t_start = time.perf_counter()
    fe_done, n_done, n_err = 0, 0, 0
    last_print = 0.0

    def handle(res, fh):
        nonlocal fe_done, n_done, n_err, last_print
        if "error_traceback" in res:
            n_err += 1
            with open(errors_path, "a", encoding="utf-8") as eh:
                eh.write(json.dumps(res, ensure_ascii=False) + "\n")
            if verbose:
                print(f"  BŁĄD f{res['fid']} {res['dim']}D seed={res['seed']} (szczegóły: {errors_path})", flush=True)
        else:
            fh.write(json.dumps(res, ensure_ascii=False) + "\n")
            fh.flush()
        n_done += 1
        fe_done += ustawienia.max_fe(res["dim"])
        now = time.perf_counter()
        if verbose and (now - last_print > 15 or n_done == len(tasks)):
            last_print = now
            elapsed = now - t_start
            eta = elapsed / fe_done * (total_fe - fe_done) if fe_done else float("nan")
            print(f"  {n_done}/{len(tasks)} przebiegów | {100 * fe_done / total_fe:5.1f}% FE | "
                  f"czas {_fmt_time(elapsed)} | pozostało ~{_fmt_time(eta)}", flush=True)

    _keep_awake(True)
    try:
        with open(out, "a", encoding="utf-8") as fh:
            if workers <= 1:
                for t in tasks:
                    handle(_task(t), fh)
            else:
                # Wektory są małe, więc wielowątkowy BLAS tylko dławi procesor przy wielu procesach.
                # Procesy robocze dziedziczą te zmienne przy starcie (zanim wczytają numpy).
                for var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
                    os.environ.setdefault(var, "1")
                custom = dict(_CUSTOM)
                with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker, initargs=(custom,)) as ex:
                    futures = [ex.submit(_task, t) for t in tasks]
                    try:
                        for fut in as_completed(futures):
                            handle(fut.result(), fh)
                    except KeyboardInterrupt:
                        print("\nPrzerwano - zapisane przebiegi zostaną pominięte przy wznowieniu.", flush=True)
                        ex.shutdown(wait=False, cancel_futures=True)
                        raise
    finally:
        _keep_awake(False)
    if verbose:
        print(f"[{algorithm}] gotowe w {_fmt_time(time.perf_counter() - t_start)}; błędów: {n_err}", flush=True)
    return out
