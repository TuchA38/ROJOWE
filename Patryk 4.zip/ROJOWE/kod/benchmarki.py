"""24 funkcje benchmarkowe BBOB (COCO, https://coco-platform.org/testsuites/bbob/overview.html).

Źródło implementacji
--------------------
Oficjalny pakiet COCO (``cocoex``) ma w kodzie C limit wymiaru 40 dla funkcji
z macierzami rotacji - dla 50D i 100D 18 z 24 funkcji kończy się błędem
"access violation". Dlatego wartości funkcji liczymy pakietem ``ioh``
(IOHexperimenter), który zawiera wierny port funkcji BBOB z COCO (te same
generatory przesunięć x_opt, f_opt i macierzy rotacji) bez limitu wymiaru.

Zgodność sprawdza ``python kod/uruchom.py weryfikuj``: dla D = 2, 3, 10, 30 i
wszystkich 24 funkcji wartości ``ioh`` i ``cocoex`` są identyczne
(różnica względna ~1e-11, czyli błąd zaokrągleń).
"""

from __future__ import annotations

from dataclasses import dataclass

import ioh
import numpy as np

import ustawienia

FUNCTION_NAMES = {
    1: "Sphere",
    2: "Ellipsoid separable",
    3: "Rastrigin separable",
    4: "Skew Rastrigin-Bueche",
    5: "Linear slope",
    6: "Attractive sector",
    7: "Step-ellipsoid",
    8: "Rosenbrock original",
    9: "Rosenbrock rotated",
    10: "Ellipsoid",
    11: "Discus",
    12: "Bent cigar",
    13: "Sharp ridge",
    14: "Sum of different powers",
    15: "Rastrigin",
    16: "Weierstrass",
    17: "Schaffer F7, condition 10",
    18: "Schaffer F7, condition 1000",
    19: "Griewank-Rosenbrock F8F2",
    20: "Schwefel x*sin(x)",
    21: "Gallagher 101 peaks",
    22: "Gallagher 21 peaks",
    23: "Katsuura",
    24: "Lunacek bi-Rastrigin",
}

FUNCTION_GROUPS = {
    "Separable": [1, 2, 3, 4, 5],
    "Low or moderate conditioning": [6, 7, 8, 9],
    "High conditioning and unimodal": [10, 11, 12, 13, 14],
    "Multi-modal with adequate global structure": [15, 16, 17, 18, 19],
    "Multi-modal with weak global structure": [20, 21, 22, 23, 24],
}
GROUP_OF = {fid: group for group, fids in FUNCTION_GROUPS.items() for fid in fids}


def function_label(fid: int) -> str:
    """Np. 'f15 Rastrigin'."""
    return f"f{fid} {FUNCTION_NAMES[fid]}"


def sheet_name(fid: int) -> str:
    """Nazwa arkusza Excela (max 31 znaków), np. 'F15_Rastrigin'."""
    name = FUNCTION_NAMES[fid]
    for ch in ",*()":
        name = name.replace(ch, "")
    name = name.replace(" ", "_")
    return f"F{fid:02d}_{name}"[:31]


@dataclass
class Benchmark:
    """Jedna funkcja BBOB w ustalonym wymiarze i instancji.

    Wywołanie ``bench(x)`` zwraca wartość funkcji (minimalizacja).
    """

    fid: int
    dim: int
    instance: int = ustawienia.INSTANCE

    def __post_init__(self):
        self._problem = ioh.get_problem(self.fid, instance=self.instance, dimension=self.dim,
                                        problem_class=ioh.ProblemClass.BBOB)
        self.name = FUNCTION_NAMES[self.fid]
        self.group = GROUP_OF[self.fid]
        self.f_opt = float(self._problem.optimum.y)
        # Uwaga: dla f19 przy D > 64 ioh podaje niedokładne x_opt (f_opt jest poprawne).
        self.x_opt = np.asarray(self._problem.optimum.x, dtype=float)
        self.lb = np.full(self.dim, ustawienia.LOWER_BOUND)
        self.ub = np.full(self.dim, ustawienia.UPPER_BOUND)

    def __call__(self, x) -> float:
        return float(self._problem(np.asarray(x, dtype=float)))

    def evaluate_many(self, X: np.ndarray) -> np.ndarray:
        """Wartości dla wielu punktów naraz (wiersze macierzy X)."""
        return np.asarray(self._problem(np.asarray(X, dtype=float)), dtype=float)

    @property
    def label(self) -> str:
        return function_label(self.fid)

    def __repr__(self) -> str:
        return f"Benchmark(f{self.fid} {self.name}, D={self.dim}, f_opt={self.f_opt})"


def get_benchmark(fid: int, dim: int, instance: int = ustawienia.INSTANCE) -> Benchmark:
    return Benchmark(fid, dim, instance)


def verify_against_coco(dims=(2, 3, 10, 30), n_points: int = 20, seed: int = 0):
    """Porównuje wartości z ioh z oficjalnym pakietem COCO (cocoex) w losowych punktach.

    cocoex działa tylko do D=40, więc 50D i 100D sprawdzamy pośrednio:
    implementacja jest ta sama dla każdego D, a f(x_opt) == f_opt.
    """
    import cocoex
    import pandas as pd

    cocoex.log_level("error")
    rng = np.random.default_rng(seed)
    rows = []
    for d in dims:
        for fid in ustawienia.FUNCTION_IDS:
            ref = cocoex.BareProblem("bbob", fid, d, ustawienia.INSTANCE)
            ours = Benchmark(fid, d)
            X = rng.uniform(ustawienia.LOWER_BOUND, ustawienia.UPPER_BOUND, (n_points, d))
            y_ref = np.array([ref(x) for x in X])
            y_our = np.array([ours(x) for x in X])
            rel = np.max(np.abs(y_ref - y_our) / np.maximum(1.0, np.abs(y_ref)))
            rows.append({"D": d, "fid": fid, "f_opt (COCO)": ref.best_value(), "f_opt (ioh)": ours.f_opt,
                         "max. różnica względna": rel, "zgodne": rel < 1e-9 and ref.best_value() == ours.f_opt})
    for d in (50, 100):
        for fid in ustawienia.FUNCTION_IDS:
            b = Benchmark(fid, d)
            gap = b(b.x_opt) - b.f_opt
            rows.append({"D": d, "fid": fid, "f_opt (COCO)": None, "f_opt (ioh)": b.f_opt,
                         "max. różnica względna": None,
                         "zgodne": abs(gap) < 1e-6 or (fid == 19 and d > 64),   # f19: niedokładne x_opt w ioh
                         "f(x_opt) - f_opt": gap})
    return pd.DataFrame(rows)


def benchmark_table(dims=None):
    """Tabela (DataFrame) z opisem wszystkich funkcji: grupa, nazwa, f_opt dla każdego wymiaru."""
    import pandas as pd

    dims = dims or ustawienia.DIMENSIONS
    rows = []
    for fid in ustawienia.FUNCTION_IDS:
        row = {"Funkcja": f"f{fid}", "Nazwa": FUNCTION_NAMES[fid], "Grupa": GROUP_OF[fid]}
        for d in dims:
            row[f"f_opt ({d}D)"] = get_benchmark(fid, d).f_opt
        rows.append(row)
    return pd.DataFrame(rows)
