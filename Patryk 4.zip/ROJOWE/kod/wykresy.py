"""Wizualizacje: funkcje benchmarkowe, krzywe zbieżności, wykresy pudełkowe, rangi,
wykresy historii MEALPY i animacja populacji (roju) w 2D."""

from __future__ import annotations

import contextlib
import os
from pathlib import Path

import matplotlib

if os.environ.get("MPLBACKEND") is None and not os.environ.get("JPY_PARENT_PID"):
    matplotlib.use("Agg")            # zapis do plików bez okna (CLI); w Jupyterze backend inline

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LogNorm

import ustawienia
from benchmarki import Benchmark, function_label, sheet_name

ERROR_FLOOR = 1e-10          # błąd 0 nie da się narysować w skali log


def _save(fig, out, dpi=150):
    if out is not None:
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=dpi, bbox_inches="tight")
    return fig


@contextlib.contextmanager
def _chdir(path: Path):
    old = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


# --------------------------------------------------------------------------
# Funkcje benchmarkowe
# --------------------------------------------------------------------------

def function_grid(fid: int, n: int = 201, instance: int = ustawienia.INSTANCE):
    bench = Benchmark(fid, 2, instance)
    xs = np.linspace(ustawienia.LOWER_BOUND, ustawienia.UPPER_BOUND, n)
    X, Y = np.meshgrid(xs, xs)
    Z = bench.evaluate_many(np.column_stack([X.ravel(), Y.ravel()])).reshape(X.shape)
    return bench, X, Y, Z


def plot_function(fid: int, out=None, n: int = 201):
    """Powierzchnia 3D i mapa konturowa (log10 błędu) funkcji w 2D z zaznaczonym optimum."""
    bench, X, Y, Z = function_grid(fid, n)
    err = np.maximum(Z - bench.f_opt, ERROR_FLOOR)
    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(1, 2, 1, projection="3d")
    ax.plot_surface(X, Y, Z, cmap="viridis", linewidth=0, antialiased=True, rcount=100, ccount=100)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel("$x_2$")
    ax.set_zlabel("$f(x)$")
    ax.set_title("Powierzchnia")
    ax2 = fig.add_subplot(1, 2, 2)
    levels = np.logspace(np.log10(max(err.min(), ERROR_FLOOR)), np.log10(err.max()), 30)
    cs = ax2.contourf(X, Y, err, levels=levels, norm=LogNorm(), cmap="viridis")
    fig.colorbar(cs, ax=ax2, label="$f(x) - f_{opt}$ (skala log)", format="%.0e")
    ax2.plot(*bench.x_opt[:2], marker="*", color="red", markersize=14, markeredgecolor="white",
             label=f"optimum $f_{{opt}}$={bench.f_opt:g}")
    ax2.set_xlabel("$x_1$")
    ax2.set_ylabel("$x_2$")
    ax2.set_title("Mapa konturowa błędu")
    ax2.legend(loc="upper right", fontsize=8)
    ax2.set_aspect("equal")
    fig.suptitle(f"{function_label(fid)} (BBOB, instancja {ustawienia.INSTANCE}, D=2)", fontsize=13)
    fig.tight_layout()
    return _save(fig, out)


def plot_all_functions(outdir=ustawienia.FUNCTIONS_FIG_DIR, n: int = 201, show: bool = False):
    """Zapisuje wizualizację każdej z 24 funkcji + zbiorczą siatkę 4x6."""
    outdir = Path(outdir)
    for fid in ustawienia.FUNCTION_IDS:
        fig = plot_function(fid, outdir / f"{sheet_name(fid)}.png", n)
        if not show:
            plt.close(fig)

    fig = plt.figure(figsize=(24, 16))
    for i, fid in enumerate(ustawienia.FUNCTION_IDS, start=1):
        bench, X, Y, Z = function_grid(fid, 121)
        ax = fig.add_subplot(4, 6, i, projection="3d")
        ax.plot_surface(X, Y, Z, cmap="viridis", linewidth=0, rcount=60, ccount=60)
        ax.set_title(function_label(fid), fontsize=10)
        ax.tick_params(labelsize=6)
    fig.suptitle("24 funkcje BBOB (D=2)", fontsize=16)
    fig.tight_layout()
    _save(fig, outdir / "all_functions_3d.png", dpi=110)
    if not show:
        plt.close(fig)

    fig, axes = plt.subplots(4, 6, figsize=(24, 16))
    for ax, fid in zip(axes.ravel(), ustawienia.FUNCTION_IDS):
        bench, X, Y, Z = function_grid(fid, 161)
        err = np.maximum(Z - bench.f_opt, ERROR_FLOOR)
        ax.contourf(X, Y, err, levels=np.logspace(np.log10(err.min()), np.log10(err.max()), 25),
                    norm=LogNorm(), cmap="viridis")
        ax.plot(*bench.x_opt[:2], "r*", markersize=10, markeredgecolor="white")
        ax.set_title(function_label(fid), fontsize=10)
        ax.set_aspect("equal")
        ax.tick_params(labelsize=7)
    fig.suptitle("24 funkcje BBOB - mapy konturowe błędu (log), czerwona gwiazdka = optimum", fontsize=16)
    fig.tight_layout()
    _save(fig, outdir / "all_functions_contour.png", dpi=110)
    if not show:
        plt.close(fig)
    return outdir


# --------------------------------------------------------------------------
# Wyniki eksperymentów
# --------------------------------------------------------------------------

def _grid(n=24, ncols=6, size=(4.0, 3.0)):
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(size[0] * ncols, size[1] * nrows))
    return fig, axes.ravel()


def plot_convergence(df: pd.DataFrame, dim: int, algos=None, out=None, band: bool = True):
    """Krzywe zbieżności: mediana najlepszego dotychczasowego błędu (pas: kwartyle 25-75%)
    w funkcji wykorzystanego budżetu FE - osobny panel dla każdej funkcji."""
    algos = algos or list(df["algorithm"].unique())
    sub = df[df["dim"] == dim]
    x = np.array(ustawienia.TRACE_CHECKPOINTS) * 100
    fig, axes = _grid()
    for ax, fid in zip(axes, ustawienia.FUNCTION_IDS):
        for algo in algos:
            grp = sub[(sub["algorithm"] == algo) & (sub["fid"] == fid)]
            if grp.empty:
                continue
            tr = np.maximum(np.vstack(grp["trace_error"].to_list()), ERROR_FLOOR)
            med = np.median(tr, axis=0)
            line, = ax.plot(x, med, label=algo, lw=1.6)
            if band:
                ax.fill_between(x, np.percentile(tr, 25, axis=0), np.percentile(tr, 75, axis=0),
                                color=line.get_color(), alpha=0.2, lw=0)
        ax.set_yscale("log")
        ax.set_title(function_label(fid), fontsize=9)
        ax.tick_params(labelsize=7)
        ax.grid(alpha=0.3)
    for ax in axes[18:]:
        ax.set_xlabel("% budżetu FE", fontsize=8)
    for ax in axes[::6]:
        ax.set_ylabel("błąd $f-f_{opt}$", fontsize=8)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=len(algos), fontsize=10, bbox_to_anchor=(0.5, 1.0))
    n_runs = sub.groupby(["algorithm", "fid"]).size()
    n_txt = str(n_runs.iloc[0]) if n_runs.nunique() == 1 else f"{n_runs.min()}-{n_runs.max()}"
    what = "mediana" + (", pas 25-75%" if band else "")
    fig.suptitle(f"Krzywe zbieżności, D={dim}, max_fe={ustawienia.max_fe(dim):,} ({what} z {n_txt} przebiegów)",
                 fontsize=13, y=1.02)
    fig.tight_layout()
    return _save(fig, out)


def plot_boxplots(df: pd.DataFrame, dim: int, algos=None, out=None):
    """Rozkład końcowego błędu z 50 przebiegów (skala log) dla każdej funkcji."""
    algos = algos or list(df["algorithm"].unique())
    sub = df[df["dim"] == dim]
    fig, axes = _grid()
    for ax, fid in zip(axes, ustawienia.FUNCTION_IDS):
        data = [np.maximum(sub[(sub["algorithm"] == a) & (sub["fid"] == fid)]["error"].to_numpy(), ERROR_FLOOR)
                for a in algos]
        if all(len(d) == 0 for d in data):
            continue
        ax.boxplot(data, showfliers=True, flierprops={"markersize": 3})
        ax.set_xticks(range(1, len(algos) + 1))
        ax.set_xticklabels([a.replace("Original", "") for a in algos], rotation=45, fontsize=7)
        ax.set_yscale("log")
        ax.set_title(function_label(fid), fontsize=9)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(alpha=0.3, axis="y")
    fig.suptitle(f"Końcowy błąd $f-f_{{opt}}$ (rozkład z wszystkich przebiegów), D={dim}", fontsize=13)
    fig.tight_layout()
    return _save(fig, out)


def plot_error_heatmap(df: pd.DataFrame, algo: str, out=None):
    """Mapa ciepła: log10 mediany błędu dla funkcji x wymiar (jedno spojrzenie na cały algorytm)."""
    sub = df[df["algorithm"] == algo]
    piv = sub.groupby(["fid", "dim"])["error"].median().unstack("dim")
    data = np.log10(np.maximum(piv.to_numpy(), ERROR_FLOOR))
    fig, ax = plt.subplots(figsize=(1.2 * piv.shape[1] + 3, 9))
    im = ax.imshow(data, aspect="auto", cmap="RdYlGn_r")
    ax.set_xticks(range(piv.shape[1]))
    ax.set_xticklabels([f"{d}D" for d in piv.columns])
    ax.set_yticks(range(piv.shape[0]))
    ax.set_yticklabels([function_label(f) for f in piv.index], fontsize=8)
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            ax.text(j, i, f"{data[i, j]:.1f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im, ax=ax, label="log10(mediana błędu)")
    ax.set_title(f"{algo}: log10 mediany błędu $f-f_{{opt}}$")
    fig.tight_layout()
    return _save(fig, out)


def plot_ranks(friedman_result: dict, out=None, title: str | None = None):
    """Średnie rangi Friedmana z zaznaczoną różnicą krytyczną Nemenyiego (CD)."""
    ranks = friedman_result["ranks"]
    fig, ax = plt.subplots(figsize=(8, 0.5 * len(ranks) + 1.5))
    ax.barh(ranks["Metoda"], ranks["Średnia ranga"], color="tab:blue", alpha=0.75)
    ax.invert_yaxis()
    if "nemenyi_CD" in friedman_result:
        best = ranks["Średnia ranga"].min()
        cd = friedman_result["nemenyi_CD"]
        ax.axvline(best + cd, color="red", ls="--", label=f"najlepsza + CD (Nemenyi) = {best + cd:.2f}")
        ax.legend(fontsize=8)
    ax.set_xlabel("Średnia ranga (mniejsza = lepsza)")
    ax.set_title(title or f"Ranking Friedmana (n={friedman_result['n_problems']} problemów)")
    fig.tight_layout()
    return _save(fig, out)


# --------------------------------------------------------------------------
# Wizualizacje MEALPY i animacja roju
# --------------------------------------------------------------------------

def mealpy_history_charts(optimizer, outdir, prefix: str = "") -> Path:
    """Wbudowane wykresy MEALPY (https://mealpy.readthedocs.io/en/latest/pages/general/visualization.html)."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    h = optimizer.history
    with _chdir(outdir):
        h.save_global_objectives_chart(filename=f"{prefix}global-objectives", verbose=False)
        h.save_local_objectives_chart(filename=f"{prefix}local-objectives", verbose=False)
        h.save_global_best_fitness_chart(filename=f"{prefix}global-best-fitness", verbose=False)
        h.save_local_best_fitness_chart(filename=f"{prefix}local-best-fitness", verbose=False)
        h.save_runtime_chart(filename=f"{prefix}runtime", verbose=False)
        h.save_exploration_exploitation_chart(filename=f"{prefix}exploration-exploitation", verbose=False)
        h.save_diversity_chart(filename=f"{prefix}diversity", algorithm_name=optimizer.get_name(), verbose=False)
        if len(h.list_population) >= 2:
            h.save_trajectory_chart(list_agent_idx=[1, 2, 3], selected_dimensions=[1, 2],
                                    filename=f"{prefix}trajectory", verbose=False)
    plt.close("all")
    return outdir


def animate_population(optimizer, fid: int, out, max_frames: int = 60, fps: int = 8):
    """Animacja GIF: położenia osobników roju na mapie konturowej funkcji 2D w kolejnych epokach.

    Wymaga uruchomienia z ``save_population=True`` (patrz ``demo_run``).
    """
    from matplotlib.animation import FuncAnimation, PillowWriter

    pops = optimizer.history.list_population
    if not pops:
        raise ValueError("Brak zapisanych populacji - uruchom z save_population=True.")
    frames = np.unique(np.linspace(0, len(pops) - 1, min(max_frames, len(pops))).astype(int))
    bench, X, Y, Z = function_grid(fid, 161)
    err = np.maximum(Z - bench.f_opt, ERROR_FLOOR)

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.contourf(X, Y, err, levels=np.logspace(np.log10(err.min()), np.log10(err.max()), 30),
                norm=LogNorm(), cmap="viridis", alpha=0.85)
    ax.plot(*bench.x_opt[:2], "r*", markersize=16, markeredgecolor="white", label="optimum")
    scat = ax.scatter([], [], s=18, c="white", edgecolors="black", linewidths=0.5, label="osobniki")
    best, = ax.plot([], [], "o", color="orange", markersize=9, markeredgecolor="black", label="najlepszy w epoce")
    ax.set_xlim(ustawienia.LOWER_BOUND, ustawienia.UPPER_BOUND)
    ax.set_ylim(ustawienia.LOWER_BOUND, ustawienia.UPPER_BOUND)
    ax.set_aspect("equal")
    ax.legend(loc="upper right", fontsize=8)
    title = ax.set_title("")

    def update(k):
        pop = pops[frames[k]]
        pos = np.array([a.solution[:2] for a in pop])
        fit = np.array([a.target.fitness for a in pop])
        scat.set_offsets(pos)
        b = pos[np.argmin(fit)]
        best.set_data([b[0]], [b[1]])
        title.set_text(f"{optimizer.get_name()} - {function_label(fid)}\n"
                       f"epoka {frames[k] + 1}/{len(pops)}, błąd={fit.min() - bench.f_opt:.2e}")
        return scat, best, title

    anim = FuncAnimation(fig, update, frames=len(frames), blit=False)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    anim.save(out, writer=PillowWriter(fps=fps))
    plt.close(fig)
    return out


def demo_run(algorithm: str, fid: int, seed: int = ustawienia.SEEDS[0], outdir=None, dim: int = 2):
    """Jedno uruchomienie demonstracyjne (2D) z zapisem populacji -> wykresy MEALPY + animacja GIF."""
    from eksperyment import run_single

    result, optimizer = run_single(algorithm, fid, dim, seed, save_population=True, return_optimizer=True)
    outdir = Path(outdir or ustawienia.REPORTS_DIR / algorithm / "demo")
    tag = f"f{fid:02d}_{dim}D_"
    mealpy_history_charts(optimizer, outdir, prefix=tag)
    gif = None
    if dim == 2:
        gif = animate_population(optimizer, fid, outdir / f"{tag}animacja.gif")
    return result, optimizer, outdir, gif
