# Jak uruchomić — krok po kroku

Algorytmy liczy się **po kolei, jeden po drugim**. Z każdego powstaje osobne sprawozdanie z wynikami dla każdego wymiaru: **2D, 3D, 10D, 30D, 50D i 100D** (wariant na 5.0).

Wszystkie polecenia działają tak samo w **PowerShellu** i w **cmd**. Wpisujesz je w terminalu i zatwierdzasz klawiszem **Enter**.

---

## 0. Przygotowanie (tylko raz)

### Otwórz terminal w folderze projektu
VS Code z folderem `rojowe` → menu **Terminal → New Terminal**. Na dole pojawi się:
```
PS C:\Users\Hania\Desktop\rojowe>
```
Jeśli jest tam inny folder, wpisz:
```
cd C:\Users\Hania\Desktop\rojowe
```

### Sprawdź, czy wszystko jest zainstalowane
```
python --version
python -m pip install -r requirements.txt
```
Pierwsze polecenie ma pokazać `Python 3.12.7`. Drugie doinstaluje brakujące biblioteki; jeśli wszystko jest, napisze tylko „Requirement already satisfied”.

### Sprawdź benchmarki (kilka sekund)
```
python kod/uruchom.py weryfikuj
```
**Co robi:** porównuje nasze 24 funkcje z oficjalnym pakietem COCO. Na końcu ma być `Zgodne: 144/144`. Do sprawozdania przydaje się zdanie, że implementacja jest zgodna z COCO.

### Wizualizacje 24 funkcji (ok. 15 sekund, już zrobione)
```
python kod/uruchom.py funkcje
```
**Co robi:** rysuje każdą z 24 funkcji w 2D (powierzchnia 3D i mapa konturowa z zaznaczonym optimum).
**Gdzie:** `raporty/funkcje_benchmarkowe/`. Instrukcja wymaga wizualizacji każdej funkcji, więc te obrazki wstawiasz do sprawozdania.

### Przed każdym długim liczeniem
- Ustawienia → System → Zasilanie → **„Uśpij” → Nigdy**. Uśpiony komputer nie liczy.
- Laptop podłącz do ładowarki i nie zamykaj klapy.
- Nie zamykaj terminala ani VS Code, dopóki liczenie się nie skończy.

---

## 1. Punkt odniesienia — RandomSearch (tylko raz, na samym początku)

```
python kod/uruchom.py oblicz RandomSearch
```
**Co liczy:** losowe przeszukiwanie, czyli w każdym kroku losuje punkty i zapamiętuje najlepszy. Liczy według dokładnie tego samego protokołu: 24 funkcje × 6 wymiarów × 50 seedów.
**Po co:** w każdym sprawozdaniu porównujesz swój algorytm z RandomSearch testami statystycznymi (Wilcoxon, Mann-Whitney + Holm). Tego wymaga wariant na 5.0.
**Czas:** ok. 1,5–3 h.

---

## 2. Schemat dla każdego algorytmu (zawsze te same 4 kroki)

### Krok A — obliczenia (najdłuższe, najlepiej na noc)
```
python kod/uruchom.py oblicz NAZWA_ALGORYTMU
```
**Co liczy:** 7200 uruchomień algorytmu = 24 funkcje × 6 wymiarów × 50 seedów (12345–12394).
- Każde uruchomienie to nowy algorytm z domyślnymi parametrami mealpy i populacja 100 osobników w przedziale [−5, 5].
- Budżet to 10 000 × wymiar wywołań funkcji: 2D = 20 000, 3D = 30 000, 10D = 100 000, 30D = 300 000, 50D = 500 000, 100D = 1 000 000.
- Dla każdego uruchomienia zapisuje się: najlepszy wynik, błąd względem optimum, czas, liczba wywołań funkcji i najlepszy wynik po 1, 5, 10, 25, 50, 75 i 100% budżetu.

**Co widzisz na ekranie:** co 15 sekund linijka typu
```
  31/7200 przebiegów |   1.9% FE | czas 4m25s | pozostało ~8h55m
```
a na koniec `gotowe ...; błędów: 0`.

**Gdzie zapisuje:** `wyniki_przebiegow/NAZWA_ALGORYTMU/runs.jsonl` (surowe wyniki) i `protocol.json` (ustawienia i wersja mealpy).

**Jeśli liczenie się przerwie** (zamknięte okno, Ctrl+C, restart): wpisz **to samo polecenie** jeszcze raz. Policzy tylko to, czego brakuje, i nic nie przepadnie.

#### Wersja na kilka krótszych sesji (zamiast jednego długiego liczenia)
Ten sam wynik, tylko podzielony na wymiary. Możesz puścić je w dowolne dni i w dowolnej kolejności:
```
python kod/uruchom.py oblicz NAZWA_ALGORYTMU --wymiary 2 3 10
python kod/uruchom.py oblicz NAZWA_ALGORYTMU --wymiary 30
python kod/uruchom.py oblicz NAZWA_ALGORYTMU --wymiary 50
python kod/uruchom.py oblicz NAZWA_ALGORYTMU --wymiary 100
```
Mniej więcej jaka część całego czasu przypada na dany wymiar: 2D + 3D + 10D ≈ 5%, 30D ≈ 12%, 50D ≈ 25%, **100D ≈ 60%**.

### Krok B — sprawdzenie, czy wszystko policzone
```
python kod/uruchom.py status
```
Przy każdym wymiarze danego algorytmu ma być `1200/1200` (24 funkcje × 50 seedów).

### Krok C — materiały do sprawozdania (kilka minut)
```
python kod/uruchom.py raport NAZWA_ALGORYTMU --porownaj RandomSearch [algorytmy z poprzednich sprawozdań]
```
**Co robi:** z surowych wyników tworzy wszystko do sprawozdania w folderze `raporty/NAZWA_ALGORYTMU/` (opis plików w punkcie 4).

### Krok D — wykresy mealpy i animacja roju (kilka sekund)
```
python kod/uruchom.py demo NAZWA_ALGORYTMU
```
**Co robi:** jedno uruchomienie na funkcji f15 Rastrigin w 2D, z zapisem całej populacji. Rysuje wykresy mealpy wskazane w instrukcji (global/local objectives, diversity, exploration–exploitation, trajectory) i animację GIF poruszania się roju.
**Gdzie:** `raporty/NAZWA_ALGORYTMU/demo/`. Inną funkcję wybierzesz np. tak: `--funkcja 21`.

---

## 3. Kolejność — wszystkie polecenia do skopiowania

### Sprawozdanie 1 — AOA (Arithmetic Optimization Algorithm), ok. 8–10 h
```
python kod/uruchom.py oblicz OriginalAOA
python kod/uruchom.py status
python kod/uruchom.py raport OriginalAOA --porownaj RandomSearch
python kod/uruchom.py demo OriginalAOA
```

### Sprawozdanie 2 — CGO (Chaos Game Optimization), ok. 3–4 h
```
python kod/uruchom.py oblicz OriginalCGO
python kod/uruchom.py status
python kod/uruchom.py raport OriginalCGO --porownaj RandomSearch OriginalAOA
python kod/uruchom.py demo OriginalCGO
```

### Sprawozdanie 3 — CircleSA (Circle Search Algorithm), ok. 2–3 h
```
python kod/uruchom.py oblicz OriginalCircleSA
python kod/uruchom.py status
python kod/uruchom.py raport OriginalCircleSA --porownaj RandomSearch OriginalAOA OriginalCGO
python kod/uruchom.py demo OriginalCircleSA
```

### Sprawozdanie 4 — GBO (Gradient-Based Optimizer), ok. 8–10 h
```
python kod/uruchom.py oblicz OriginalGBO
python kod/uruchom.py status
python kod/uruchom.py raport OriginalGBO --porownaj RandomSearch OriginalAOA OriginalCGO OriginalCircleSA
python kod/uruchom.py demo OriginalGBO
```

### Sprawozdanie 5 — INFO (weIghted meaN oF vectOrs), ok. 8–10 h
```
python kod/uruchom.py oblicz OriginalINFO
python kod/uruchom.py status
python kod/uruchom.py raport OriginalINFO --porownaj RandomSearch OriginalAOA OriginalCGO OriginalCircleSA OriginalGBO
python kod/uruchom.py demo OriginalINFO
```

### Sprawozdanie 6 — EP (Evolutionary Programming, Extra), ok. 4–5 h
```
python kod/uruchom.py oblicz OriginalEP
python kod/uruchom.py status
python kod/uruchom.py raport OriginalEP --porownaj RandomSearch OriginalAOA OriginalCGO OriginalCircleSA OriginalGBO OriginalINFO
python kod/uruchom.py demo OriginalEP
```

### Rozdział podsumowujący — wszystkie algorytmy razem (kilka minut)
```
python kod/uruchom.py porownanie OriginalAOA OriginalCGO OriginalCircleSA OriginalGBO OriginalINFO OriginalEP
```
**Co robi:** ranking wszystkich 6 algorytmów (test Friedmana dla każdego wymiaru i łącznie, Nemenyi, Holm), test Wilcoxona dla każdej pary, wspólne wykresy zbieżności i pudełkowe dla każdego wymiaru.
**Gdzie:** `raporty/porownanie/`.

> Dlaczego `--porownaj` się wydłuża: od 2. sprawozdania porównujesz z co najmniej 2 innymi algorytmami, więc raport zawiera też **test Friedmana** z testami Nemenyiego i Holma. Do `--porownaj` wpisuj tylko algorytmy, które są już w pełni policzone.

---

## 4. Co znajdziesz w `raporty/NAZWA_ALGORYTMU/` i gdzie to wstawić

Przykład dla AOA (akronim w nazwach plików to `AOA`, dla CircleSA to `CircleSA` itd.).

### `AOA_wyniki.xlsx` — plik z wynikami do oddania na Classroom
| Arkusz | Zawartość |
|---|---|
| Protokół | parametry algorytmu, wersja mealpy, budżety, seedy |
| Kompletność | czy w każdym wymiarze jest 1200 przebiegów |
| Podsumowanie | dla każdej funkcji i wymiaru: wartość optimum, średnia, odchylenie, średni błąd, mediana, średni czas, odchylenie czasu |
| Wyniki 50 powtórzeń | tabela z instrukcji: Metoda, Funkcja, Wartość optimum, 50 wyników, Średnia, Odch. std, Średni czas, Odch. std czasu |
| Zbieżność (fitness / błąd) | najlepszy dotychczasowy wynik przy 1, 5, 10, 25, 50, 75, 100% FE |
| Shapiro-Wilk, MW vs …, Wilcoxon, Friedman, Holm, Nemenyi, Levene | testy statystyczne |
| F01_Sphere … F24_Lunacek | każdy z 50 przebiegów dla każdego wymiaru, z progami zbieżności |

### `latex/` — gotowe tabele do wklejenia w sprawozdanie (Overleaf)
| Plik | Do którego punktu sprawozdania |
|---|---|
| `AOA_wyniki_2D.tex` … `AOA_wyniki_100D.tex` | wyniki dla danego wymiaru (jedna tabela na wymiar) |
| `AOA_zbieznosc_2D.tex` … `AOA_zbieznosc_100D.tex` | tabela przebiegu zbieżności dla danego wymiaru |
| `AOA_testy.tex` | tabela testu Wilcoxona (i Friedmana od 2. sprawozdania) |

W Overleafie w preambule muszą być: `\usepackage{booktabs}` i `\usepackage{graphicx}`. Tabelę wstawiasz poleceniem `\input{AOA_wyniki_2D.tex}` po wgraniu pliku do projektu.

### `wykresy/`
| Plik | Co pokazuje |
|---|---|
| `AOA_zbieznosc_2D.png` … `_100D.png` | krzywe zbieżności dla 24 funkcji w danym wymiarze |
| `AOA_boxplot_2D.png` … `_100D.png` | rozkład wyników z 50 uruchomień dla każdej funkcji |
| `AOA_heatmapa.png` | jedno spojrzenie na całość: jak dobry jest wynik dla każdej funkcji i wymiaru |
| `AOA_rangi_friedman.png` | ranking algorytmów (od 2. sprawozdania) |

### `demo/`
Wykresy mealpy i animacja roju `f15_2D_animacja.gif`.

### Proponowany układ sprawozdania (zgodnie z instrukcją)
1. Strona tytułowa: tytuł i autor.
2. Opis teoretyczny metody.
3. Pseudokod z artykułu z opisem.
4. Kod w Pythonie z opisem. Kod algorytmu z mealpy jest w pliku
   `C:\Users\Hania\AppData\Local\Programs\Python\Python312\Lib\site-packages\mealpy\...`
   (np. `math_based\AOA.py`; polecenie `python kod/uruchom.py info OriginalAOA` pokazuje nazwę klasy i parametry).
5. Wyniki — **osobny podrozdział dla każdego wymiaru** 2D, 3D, 10D, 30D, 50D, 100D. W każdym:
   - tabela wyników `AOA_wyniki_<D>D.tex`,
   - tabela zbieżności `AOA_zbieznosc_<D>D.tex`,
   - wykres zbieżności i wykres pudełkowy dla tego wymiaru,
   - 2–3 zdania komentarza.
6. Testy statystyczne: tabela `AOA_testy.tex` i krótki opis, np. „test Wilcoxona: p = …, więc różnica jest istotna”. **To jest warunek oceny 5.0.**
7. Podsumowanie i wnioski.

Pliki kodów algorytmów:

| Algorytm | Plik w mealpy |
|---|---|
| AOA | `math_based\AOA.py` |
| CGO | `math_based\CGO.py` |
| CircleSA | `math_based\CircleSA.py` |
| GBO | `math_based\GBO.py` |
| INFO | `math_based\INFO.py` |
| EP | `evolutionary_based\EP.py` |

---

## 5. Co oddajesz (wg instrukcji)

| Plik | Co do niego wchodzi |
|---|---|
| `AOA_Python.zip` | folder `kod/` + `requirements.txt` + notebook (bez folderów `__pycache__`, `wyniki_przebiegow`, `raporty`) |
| `Nazwisko_Imię_sprawozdanie.zip` | źródła LaTeX z Overleafa + PDF |
| `AOA_wyniki.xlsx` | z `raporty/OriginalAOA/` |

---

## 6. Gdy coś pójdzie nie tak

| Sytuacja | Co zrobić |
|---|---|
| liczenie się przerwało | wpisz to samo polecenie `oblicz` jeszcze raz — dokończy brakujące |
| `status` pokazuje mniej niż 1200 | jak wyżej |
| na końcu `błędów: X` większe od 0 | szczegóły są w `wyniki_przebiegow/NAZWA/errors.jsonl`; uruchom `oblicz` ponownie |
| `raport` mówi „Brak wyników dla …” | algorytm z `--porownaj` nie jest jeszcze policzony — usuń go z listy |
| `python` nie jest rozpoznawane | zamknij i otwórz VS Code (PATH) |
| komputer bardzo zwolnił | to normalne podczas liczenia — używa prawie wszystkich rdzeni |
| chcę zatrzymać liczenie | **Ctrl+C** w terminalu — nic nie przepadnie |

**Nie uruchamiaj dwóch obliczeń naraz.** Każde i tak zajmuje prawie cały procesor, więc oba liczyłyby się wolniej.
