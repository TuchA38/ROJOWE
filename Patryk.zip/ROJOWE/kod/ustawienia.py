"""Ustawienia projektu: protokół eksperymentalny z instrukcji (SI_praca_semestralna_v03.pdf)
i lista algorytmów z tematu nr 39.

Zmiana czegokolwiek tutaj zmienia warunki dla WSZYSTKICH algorytmów,
dzięki czemu każde sprawozdanie korzysta z identycznego protokołu.
"""

from pathlib import Path

# --- Algorytmy z tematu nr 39 (kolumny 1-5 + Extra) ---------------------------
ALGORYTMY_TEMATU_26 = [
    "OriginalIWO",      # kolumna 1 - Invasive Weed Optimization
    "DevTPO",           # kolumna 2 - Tree Physiology Optimization
    "OriginalTSA",      # kolumna 3 - Tunicate Swarm Algorithm
    "OriginalArchOA",   # kolumna 4 - Archimedes Optimization Algorithm
    "OriginalASO",      # kolumna 5 - Atom Search Optimization
    "OriginalSA",       # Extra     - Simulated Annealing
]

# --- Foldery -------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = PROJECT_ROOT / "wyniki_przebiegow"            # surowe wyniki (runs.jsonl) każdego algorytmu
REPORTS_DIR = PROJECT_ROOT / "raporty"                      # xlsx, tabele LaTeX, wykresy
FUNCTIONS_FIG_DIR = REPORTS_DIR / "funkcje_benchmarkowe"    # wizualizacje 24 funkcji

# --- Benchmarki BBOB (COCO) ----------------------------------------------------
FUNCTION_IDS = list(range(1, 25))         # f1 ... f24
INSTANCE = 1                              # instancja BBOB (przesunięcie/rotacja) - ta sama we wszystkich próbach
LOWER_BOUND, UPPER_BOUND = -5.0, 5.0      # dziedzina BBOB: [-5, 5]^D

# --- Wymiarowości i budżet -----------------------------------------------------
DIMENSIONS = [2, 3, 10, 30, 50, 100]
FE_PER_DIMENSION = 10_000                 # max_fe = 10 000 * D (tabela w instrukcji)
EPOCH = 100_000                           # techniczny limit iteracji - nie ogranicza eksperymentu

# Warianty oceny z instrukcji
GRADE_DIMENSIONS = {
    "3.0": [2, 3, 10],
    "4.0": [2, 3, 10, 30, 50, 100],
    "5.0": [2, 3, 10, 30, 50, 100],       # + testy statystyczne
}


def max_fe(dim: int) -> int:
    """Budżet ocen funkcji celu dla danej wymiarowości (2D -> 20 000, ..., 100D -> 1 000 000)."""
    return FE_PER_DIMENSION * dim


# --- Ziarna --------------------------------------------------------------------
SEEDS = list(range(12345, 12395))         # 50 ziaren: 12345 ... 12394
assert len(SEEDS) == 50

# --- Punkty kontrolne zbieżności (ułamek budżetu FE) ---------------------------
# Wymagane w instrukcji: 1%, 5%, 10%, 25%, 50%, 75%, 100% FE
REPORT_CHECKPOINTS = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 1.00]
# Rejestrujemy gęściej (co 1%), żeby rysować gładkie krzywe zbieżności;
# wymagane punkty są podzbiorem tej siatki.
TRACE_CHECKPOINTS = [round(k / 100, 2) for k in range(1, 101)]
assert set(REPORT_CHECKPOINTS) <= set(TRACE_CHECKPOINTS)

# Próg "rozwiązania" (standard COCO) - zapisujemy po ilu FE błąd spadł poniżej
TARGET_PRECISION = 1e-8
